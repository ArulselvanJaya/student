-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2016 at 04:05 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `yiiadvanced`
--

-- --------------------------------------------------------

--
-- Table structure for table `backenduser`
--

CREATE TABLE IF NOT EXISTS `backenduser` (
  `b_id` int(12) NOT NULL,
  `b_name` varchar(20) NOT NULL,
  `b_username` varchar(20) NOT NULL,
  `b_password` varchar(20) NOT NULL,
  `b_authkey` varchar(50) NOT NULL,
  `b_status` tinyint(1) NOT NULL,
  `b_createdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `backenduser`
--

INSERT INTO `backenduser` (`b_id`, `b_name`, `b_username`, `b_password`, `b_authkey`, `b_status`, `b_createdate`) VALUES
(1, 'Arulselvan', 'arul', 'arul', 'sdss', 1, '2016-11-28 12:12:54');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `stud_id` int(11) NOT NULL,
  `stud_name` varchar(50) NOT NULL,
  `stud_roll_no` varchar(10) NOT NULL,
  `stud_psw` varchar(20) NOT NULL,
  `stud_age` smallint(3) NOT NULL,
  `stud_standard` varchar(10) NOT NULL,
  `stud_status` tinyint(1) NOT NULL,
  `stud_create_date` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`stud_id`, `stud_name`, `stud_roll_no`, `stud_psw`, `stud_age`, `stud_standard`, `stud_status`, `stud_create_date`) VALUES
(1, 'Student 1', 'stu01', 'stu01', 11, '5 TH', 1, 0),
(2, 'Student 2', 'stu02', 'stu02', 11, '5 TH', 1, 0),
(3, 'Student 3', 'stu03', 'stu03', 12, '5 TH', 1, 0),
(4, 'Student 4', 'stu04', 'stu04', 11, '5 TH', 1, 0),
(5, 'Student 5', 'stu01', 'stu05', 12, '5 TH', 1, 0),
(6, 'Student 6', 'stu01', 'stu06', 11, '5 TH', 1, 0),
(7, 'Student 7', 'stu01', 'stu07', 11, '5 TH', 1, 0),
(8, 'Student 8', 'stu01', 'stu08', 12, '5 TH', 1, 0),
(9, 'Student 9', 'stu01', 'stu09', 11, '5 TH', 1, 0),
(10, 'Student 10', 'stu01', 'stu10', 12, '5 TH', 1, 0),
(11, 'Student 11', 'stu01', 'stu11', 11, '5 TH', 1, 0),
(12, 'Student 12', 'stu01', 'stu12', 11, '5 TH', 1, 0),
(13, 'Student 13', 'stu01', 'stu13', 12, '5 TH', 1, 0),
(14, 'Student 14', 'stu01', 'stu14', 12, '5 TH', 1, 0),
(15, 'Student 15', 'stu01', 'stu15', 11, '5 TH', 1, 0),
(16, 'Student 16', 'stu01', 'stu16', 11, '5 TH', 1, 0),
(17, 'Student 17', 'stu01', 'stu17', 12, '5 TH', 1, 0),
(18, 'Student 18', 'stu01', 'stu18', 11, '5 TH', 1, 0),
(19, 'Student 19', 'stu01', 'stu19', 12, '5 TH', 1, 0),
(20, 'Student 20', 'stu01', 'stu20', 11, '5 TH', 1, 0),
(21, 'Student 21', 'stu01', 'stu21', 12, '5 TH', 1, 0),
(22, 'Student 22', 'stu01', 'stu22', 11, '5 TH', 1, 0),
(23, 'Student 23', 'stu01', 'stu23', 12, '5 TH', 1, 0),
(24, 'Student 24', 'stu01', 'stu24', 12, '5 TH', 1, 0),
(25, 'Student 25', 'stu01', 'stu25', 11, '5 TH', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
  `subject_id` int(11) NOT NULL,
  `subject_name` varchar(20) NOT NULL,
  `subject_stuatus` tinyint(1) NOT NULL,
  `subject_create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subject_id`, `subject_name`, `subject_stuatus`, `subject_create_date`) VALUES
(1, 'English', 1, '2016-11-29 05:54:12'),
(2, 'Maths', 1, '2016-11-29 05:54:12'),
(3, 'Science', 1, '2016-11-29 05:54:26');

-- --------------------------------------------------------

--
-- Table structure for table `subject_entry`
--

CREATE TABLE IF NOT EXISTS `subject_entry` (
  `se_id` int(11) NOT NULL,
  `se_stud_id` int(11) NOT NULL,
  `se_exam_type` varchar(20) NOT NULL,
  `se_set_id` int(11) NOT NULL,
  `se_subj_id` int(11) NOT NULL,
  `se_subj_mark` int(11) NOT NULL,
  `se_subj_rank` int(11) NOT NULL,
  `se_status` tinyint(1) NOT NULL DEFAULT '1',
  `se_create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subject_entry_total`
--

CREATE TABLE IF NOT EXISTS `subject_entry_total` (
  `set_id` int(11) NOT NULL,
  `set_stud_id` int(11) NOT NULL,
  `set_exam_type` varchar(20) NOT NULL,
  `set_exam_total` int(11) NOT NULL,
  `set_exam_avg` float(5,2) NOT NULL,
  `set_rank` int(11) NOT NULL,
  `set_create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `backenduser`
--
ALTER TABLE `backenduser`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `subject_entry`
--
ALTER TABLE `subject_entry`
  ADD PRIMARY KEY (`se_id`);

--
-- Indexes for table `subject_entry_total`
--
ALTER TABLE `subject_entry_total`
  ADD PRIMARY KEY (`set_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `backenduser`
--
ALTER TABLE `backenduser`
  MODIFY `b_id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `stud_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `subject_entry`
--
ALTER TABLE `subject_entry`
  MODIFY `se_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `subject_entry_total`
--
ALTER TABLE `subject_entry_total`
  MODIFY `set_id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
