<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "backenduser".
 *
 * @property integer $b_id
 * @property string $b_name
 * @property string $b_username
 * @property string $b_password
 * @property string $b_authkey
 * @property integer $b_status
 * @property string $b_createdate
 */
class Backenduser extends \yii\db\ActiveRecord implements \yii\web\IdentityInterface
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'backenduser';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
           // [['b_name', 'b_username', 'b_password', 'b_authkey', 'b_status'], 'required'],
            [['b_username'],'unique'],
            [['b_authkey'],'unique'],
            [['b_status'], 'integer'],
            [['b_name', 'b_username', 'b_password'], 'string', 'max' => 20],
            [['b_authkey'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'b_id' => 'B ID',
            'b_name' => ' Name',
            'b_username' => 'Username',
            'b_password' => 'Password',
            'b_authkey' => 'Authkey',
            'b_status' => 'Status',
            'b_createdate' => 'Createdate',
        ];
    }

    public function getAuthKey()
    {
        return $this->b_authkey;
    }

    public function getId() 
    {
         return $this->b_id;
    }

    public function validateAuthKey($authKey) 
    {
        return $this->b_authkey === $authKey;
    }

    public static function findIdentity($id)
    {
        return self::findOne($id);
    }

    public static function findIdentityByAccessToken($token, $type = null) 
    {
        throw new \yii\base\NotSupportedException();
    }
    public static function findByUsername($username)
    {
        return self::findOne(['b_username'=>$username]);
    }
    public function validatePassword($password)
    {
        return $this->b_password === $password;
    }
}
