<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "subject_entry".
 *
 * @property integer $se_id
 * @property integer $se_stud_id
 * @property string $se_exam_type
 * @property integer $se_subj_id
 * @property integer $se_subj_mark
 * @property integer $se_subj_rank
 * @property integer $se_status
 * @property string $se_create_date
 */
class SubjectEntry extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'subject_entry';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['se_stud_id', 'se_exam_type', 'se_subj_id', 'se_subj_mark'], 'required'],
            [['se_stud_id', 'se_subj_id', 'se_subj_mark', 'se_subj_rank', 'se_status'], 'integer'],
            [['se_create_date'], 'safe'],
            [['se_exam_type'], 'string', 'max' => 20],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'se_id' => 'Se ID',
            'se_stud_id' => 'Se Stud ID',
            'se_exam_type' => 'Se Exam Type',
            'se_subj_id' => 'Se Subj ID',
            'se_subj_mark' => 'Se Subj Mark',
            'se_subj_rank' => 'Se Subj Rank',
            'se_status' => 'Se Status',
            'se_create_date' => 'Se Create Date',
        ];
    }
}
