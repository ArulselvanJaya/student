<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "subject".
 *
 * @property integer $subject_id
 * @property string $subject_name
 * @property integer $subject_stuatus
 * @property string $subject_create_date
 */
class Subject extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'subject';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['subject_name', 'subject_stuatus'], 'required'],
            [['subject_stuatus'], 'integer'],
            [['subject_create_date'], 'safe'],
            [['subject_name'], 'string', 'max' => 20],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'subject_id' => 'Subject ID',
            'subject_name' => 'Subject Name',
            'subject_stuatus' => 'Subject Stuatus',
            'subject_create_date' => 'Subject Create Date',
        ];
    }
}
