<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "subject_entry_total".
 *
 * @property integer $set_id
 * @property string $set_exam_type
 * @property integer $set_exam_total
 * @property double $set_exam_avg
 * @property integer $set_rank
 * @property string $set_create_date
 */
class SubjectTotal extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'subject_entry_total';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['set_exam_type', 'set_exam_total', 'set_exam_avg', 'set_stud_id'], 'required'],
            [['set_exam_total', 'set_rank'], 'integer'],
            [['set_exam_avg'], 'number'],
            [['set_create_date'], 'safe'],
            [['set_exam_type'], 'string', 'max' => 20],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'set_id' => 'Set ID',
            'set_exam_type' => 'Set Exam Type',
            'set_exam_total' => 'Set Exam Total',
            'set_exam_avg' => 'Set Exam Avg',
            'set_rank' => 'Set Rank',
            'set_create_date' => 'Set Create Date',
        ];
    }
	public function getEntry()
    {
        return $this->hasMany(SubjectEntry::className(), ['se_set_id' => 'set_id']);
    }
	
}
