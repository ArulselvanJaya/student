<?php

namespace common\models;

use Yii;

/**
 * This is the model class for table "students".
 *
 * @property integer $stud_id
 * @property string $stud_name
 * @property string $stud_roll_no
 * @property string $stud_psw
 * @property integer $stud_age
 * @property string $stud_standard
 * @property integer $stud_status
 * @property integer $stud_create_date
 */
class Students extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
	public $exam_type;
    public static function tableName()
    {
        return 'students';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['stud_roll_no', 'stud_psw','exam_type'], 'required'],
            [['stud_age', 'stud_status', 'stud_create_date'], 'integer'],
            [['stud_name'], 'string', 'max' => 50],
            [['stud_roll_no', 'stud_standard'], 'string', 'max' => 10],
            [['stud_psw'], 'string', 'max' => 20],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'stud_id' => 'Stud ID',
            'stud_name' => 'Stud Name',
            'stud_roll_no' => 'Roll No',
            'stud_psw' => 'Password',
            'stud_age' => 'Stud Age',
            'stud_standard' => 'Stud Standard',
            'stud_status' => 'Stud Status',
            'stud_create_date' => 'Stud Create Date',
        ];
    }
}
