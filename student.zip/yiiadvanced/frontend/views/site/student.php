<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \frontend\models\SignupForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use frontend\controllers\SiteController;
$studno=0;
$this->title = 'Marks Entry';


?>
<div class="site-signup">
    <h1><?= Html::encode($this->title) ?></h1>
	<div class="row">
		<?= Html::label('Exam Type', 'exam_tpe', ['class' => 'col-sm-3']) ?>
		<div class="col-md-4">
			<?= Html::dropDownList( 'exam_tpe',$type, ['midterm'=>'Midterm','quarterly'=>'Quarterly','halfyearly'=>'Halfyearly','annual'=>'Annual'], ['class' => 'form-control ','prompt'=>'--Select Exam Type--','id'=>'exam_tpe']) ?>
		</div>
	</div>
    <div class="row">
        <div class="col-lg-12">
            <?php //$form = ActiveForm::begin(['id' => 'form-signup']); ?>
				 <div class="row test">
					<?= Html::label('S.No', 'sno', ['class' => 'col-sm-1']) ?>
					<?= Html::label('Name', 'Name', ['class' =>'col-md-2']) ?>
					<?= Html::label('Roll NO', 'Roll No', ['class' =>'col-md-1']) ?>
					<?php foreach($subjetlist as $subject): 
							echo Html::label(  $subject->subject_name, $subject->subject_name, ['class' =>'col-md-1']);
						endforeach;
					?>
					<?= Html::label('Total', 'Total', ['class' =>'col-md-1']) ?>
					<?= Html::label('Average', 'Average', ['class' =>'col-md-1']) ?>
					<?= Html::label('Rank', 'Rank', ['class' =>'col-md-1']) ?>
					<?= Html::label('Action', 'Action', ['class' =>'col-md-1']) ?>
				</div>
				<?php if(empty($type)): ?>
					<div class="row test">
						<div class="alert alert-info">
							<strong>Exam Type?</strong> Please choose exam type
						</div>
					</div>
				<?php else: ?>
					<?php foreach($namelist as $name): $i=0?>
						<div class="row test">
							<?= Html::hiddenInput('stdid', $name->stud_id); ?>
							<?= Html::hiddenInput('markid', ''); ?>
							<?= Html::label(++$studno, 'sno', ['class' => 'col-sm-1 col1'])		 ?> 
							<?= Html::label($name->stud_name, 'Name', ['class' =>'col-md-2 col2'])		 ?>
							<?= Html::label($name->stud_roll_no, 'Name', ['class' =>'col-md-1 col2'])		 ?>
							<div id="mark_<?= $studno ?>">
								<?php $data['studId'] = $name->stud_id;
									  $data['examType'] = $type;
									  $data['studno'] = $studno;
								SiteController::upmarksnew($data); ?>
							</div>
						</div>
					<?php endforeach; ?>
				<?php endif; ?>
				
				

            <?php //ActiveForm::end(); ?>
        </div>
    </div>
</div>
<?= $this->render('css'); ?>
