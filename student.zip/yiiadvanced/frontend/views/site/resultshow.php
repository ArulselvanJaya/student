<?php //echo '<pre>';print_r($getTotals);exit; 
use yii\helpers\Html;

?>

 <div class="row">
	<div class="col-lg-12 col-md-offset-2">
		 <div class="row test">
			<?= Html::label('Name', 'Name', ['class' =>'col-md-2']) ?>
			<?= Html::label('Roll NO', 'Roll No', ['class' =>'col-md-1']) ?>
			<?php foreach($subjetlist as $subject): 
					echo Html::label(  $subject->subject_name, $subject->subject_name, ['class' =>'col-md-1']);
				endforeach;
			?>
			<?= Html::label('Total', 'Total', ['class' =>'col-md-1']) ?>
			<?= Html::label('Average', 'Average', ['class' =>'col-md-1']) ?>
			<?= Html::label('Rank', 'Rank', ['class' =>'col-md-1']) ?>
			
		</div>
		<?php if(!empty($getTotals)): ?>
			<div class="row test">
				<?= Html::label($student->stud_name, $student->stud_name, ['class' =>'col-md-2 col3']) ?>
				<?= Html::label($student->stud_roll_no, $student->stud_roll_no, ['class' =>'col-md-1 col3']) ?>
				<?php foreach($getTotals->entry as $mark): 
						echo Html::label(  $mark->se_subj_mark, $mark->se_subj_mark, ['class' =>'col-md-1 col3']);
					endforeach;
				?>
				<?= Html::label($getTotals->set_exam_total, $getTotals->set_exam_total, ['class' =>'col-md-1 col3']) ?>
				<?= Html::label($getTotals->set_exam_avg, $getTotals->set_exam_avg, ['class' =>'col-md-1 col3']) ?>
				<?= Html::label($getTotals->set_rank, $getTotals->set_rank, ['class' =>'col-md-1 col3']) ?>
			</div>
		<?php else: ?>
			<div class="row test">
				<div class=" col-md-9 col3">
					Result not found
				</div>
			</div>
		<?php endif; ?>
	</div>
</div>
<div class="jumbotron">
	<p><a class="btn btn-lg btn-info" href="index.php?r=site/result">Reset</a></p>
</div>
<?= $this->render('css'); ?>