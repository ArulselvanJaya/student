<style >
.test [class*="col-"] 
{
    padding: 15px;
    background-color: #daa3a3;
    border: 1px solid #D8D8D8;
}
.col1
{
	background-color: #e4e2c9 !important;
}
.col2
{
	background-color: #e2d6d6 !important;
}
.col3
{
	background-color: #64d0ae !important;
}
.col4
{
	background-color: #64d0ae !important;
}
.col5
{
	background-color: #64d0ae !important;
}
.col6
{
	background-color: #64d0ae !important;
}
.col7
{
	background-color: #64d0ae !important;
}
.col8
{
	background-color: #64d0ae !important;
}
.col9
{
	background-color: #e9fff8 !important;
}
.colcm
{
	background-color: #ffffff !important;
}
</style> 
<?php
echo $this->registerJs('
 $("#exam_tpe").change(function(){
	window.location.href = "index.php?r=site%2Fstudent&type="+$(this).val();
	})');
	?>
<script type="text/javascript">
function validateval(data)
{
	var value = $(data).val();
	if(value>100)
	{
		$(data).val(0);
		alert('Mark should be entere maximum 100');
	}
		
}
</script>
