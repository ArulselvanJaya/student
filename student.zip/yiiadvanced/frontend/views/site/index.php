<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="site-index">
	<div class="jumbotron">
		<?php if (Yii::$app->user->isGuest): ?>
			 <h1>Student Database</h1>
			<p><a class="btn btn-lg btn-success" href="index.php?r=site/login">Staff Login</a></p>
			<p><a class="btn btn-lg btn-info" href="index.php?r=site/result">Student Result</a></p>
		<?php else: 
				echo '<h1> Welcome to '.ucfirst(Yii::$app->user->identity->b_username).'</h1>';?>
			<p><a class="btn btn-lg btn-success" href="index.php?r=site/student">Mark Entry</a></p>
		<?php endif; ?>
    </div>
</div>
