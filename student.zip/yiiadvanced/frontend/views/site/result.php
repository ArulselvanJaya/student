<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap\ActiveForm */
/* @var $model \common\models\LoginForm */

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;

$this->title = 'Result';

?>
<div class="site-login">
    <h1><?= Html::encode($this->title) ?></h1>
	<?php if($model->load(Yii::$app->request->post())): ?>
		<div class="site-error">
			<div class="alert alert-danger">
				Invalid information  
			</div>
		</div>
	<?php endif; ?>
	<div class="row">
        <div class="col-lg-5">
            <?php $form = ActiveForm::begin(['id' => 'login-form']); ?>
				
				<?= $form->field($model, 'exam_type')->dropDownList( ['midterm'=>'Midterm','quarterly'=>'Quarterly','halfyearly'=>'Halfyearly','annual'=>'Annual'],['class' => 'form-control ','prompt'=>'--Exam Type--','id'=>'exam_tpe','autofocus' => true]) ?>
				<?= $form->field($model, 'stud_roll_no')->textInput() ?>

                <?= $form->field($model, 'stud_psw')->passwordInput() ?>

                

                <div class="form-group">
                    <?= Html::submitButton('Get Result', ['class' => 'btn btn-primary', 'name' => 'login-button']) ?>
                </div>

            <?php ActiveForm::end(); ?>
        </div>
    </div>
</div>
