<?php
namespace frontend\controllers;

use Yii;
use yii\base\InvalidParamException;
use yii\web\BadRequestHttpException;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use common\models\LoginForm;
use common\models\Students;
use common\models\Subject;
use common\models\SubjectTotal;
use common\models\SubjectEntry;
use frontend\models\ResetPasswordForm;
use frontend\models\ContactForm;
use yii\helpers\Html;
/**
 * Site controller
 */
class SiteController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'access' => [
                'class' => AccessControl::className(),
                'only' => ['logout', 'signup','student','upmarks'],
                'rules' => [
                    [
                        'actions' => ['signup'],
                        'allow' => true,
                        'roles' => ['?'],
                    ],
                    [
                        'actions' => ['logout'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
					[
                        'actions' => ['student'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
					[
                        'actions' => ['upmarks'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function actions()
    {
        return [
            'error' => [
                'class' => 'yii\web\ErrorAction',
            ],
            'captcha' => [
                'class' => 'yii\captcha\CaptchaAction',
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return mixed
     */
    public function actionIndex()
    {
        return $this->render('index');
    }

    /**
     * Logs in a user.
     *
     * @return mixed
     */
    public function actionLogin()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        } else {
            return $this->render('login', [
                'model' => $model,
            ]);
        }
    }
	
	/**
     * Logs out the current user.
     *
     * @return mixed
     */
	
	public function actionResult()
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new Students();
        if($model->load(Yii::$app->request->post()))
		{
			$student = Students::find()
							->onCondition(['stud_roll_no'=>$_POST['Students']['stud_roll_no'],'stud_psw'=>$_POST['Students']['stud_psw']])
							->one();
			if(!empty($student))
			{
				$subjetlist = Subject::findAll(['subject_stuatus' => '1',]);
				$getTotals = SubjectTotal::find()
								->where(["set_exam_type"=>$_POST['Students']['exam_type'],'set_stud_id'=>$student->stud_id])
								->with('entry')
								->one();
				
								//->onCondition(['student.stud_roll_no'=>$_POST['Students']['stud_roll_no']])
				return $this->render('resultshow', [
					'model' => $model,'subjetlist'=>$subjetlist,'getTotals'=>$getTotals,'student'=>$student
				]);
			}
			
		}
        return $this->render('result', [
                'model' => $model,
            ]);
        
    }
	
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    public function actionStudent()
	{
		$type = '';
		$namelist 	= Students::findAll(['stud_status' => '1',]);
		$subjetlist = Subject::findAll(['subject_stuatus' => '1',]);
		if(!empty($_GET['type']))
			$type = $_GET['type'];
		$getTotals = SubjectTotal::find()
							->with('entry')
							->count();
		return $this->render('student', [ 'namelist' => $namelist, 'subjetlist' => $subjetlist,'getTotals'=>$getTotals,'type'=>$type ]);
	}
	public function actionUpmarks()
	{	
		/* $_POST['examType'] ='midterm';
		$_POST['studId'] ='1';
		$_POST['studno'] = '1'; */
		
		$getTotals = SubjectTotal::find()
							->where(["set_exam_type"=>$_POST['examType'], "set_stud_id"=>$_POST['studId']])
							->with('entry')
							->one();
		
		$this->getupmarkdesign($getTotals,$_POST);
		
	}
	
	public function getupmarkdesign($getTotals,$data)
	{
		
		$subjectId = array('1'=>'Sub1','2'=>'Sub2','3'=>'Sub3');
		$studno = $data['studno'];
		if(!empty($getTotals)):
			foreach($getTotals->entry as $sub):
				
				if($sub->se_subj_id == '1')
				{
					$sub1 = Html::textInput( $subjectId[1], $sub->se_subj_mark, ['onkeyup'=>'validateval(this)','class' =>'col-md-1 colcm','id'=>$subjectId[1].$studno]);
					unset($subjectId[1]);
				}
				elseif($sub->se_subj_id == '2')
				{
					$sub2 =  Html::textInput( $subjectId[2], $sub->se_subj_mark, ['onkeyup'=>'validateval(this)','class' =>'col-md-1 colcm','id'=>$subjectId[2].$studno]);
					unset($subjectId[2]);
				}
				elseif($sub->se_subj_id == '3')
				{
					$sub3 = Html::textInput( $subjectId[3], $sub->se_subj_mark, ['onkeyup'=>'validateval(this)','class' =>'col-md-1 colcm','id'=>$subjectId[3].$studno]);
					unset($subjectId[3]);
				}
			 endforeach;
		
			 foreach( $subjectId as $key=>$val):
				if($key == '1')
					$sub1 = Html::textInput( $val, 0, ['onkeyup'=>'validateval(this)','class' =>'col-md-1 colcm','id'=>$val.$studno]);
				elseif($key == '2')
					$sub2 = Html::textInput( $val, 0, ['onkeyup'=>'validateval(this)','class' =>'col-md-1 colcm','id'=>$val.$studno]);
				elseif($key == '3')
					$sub3 = Html::textInput( $val, 0, ['onkeyup'=>'validateval(this)','class' =>'col-md-1 colcm','id'=>$val.$studno]);
			endforeach;
		echo $sub1.$sub2.$sub3;
		$action = "Update";
		?>
		<?= Html::label($getTotals->set_exam_total, $getTotals->set_exam_total, ['class' =>'col-md-1 col6']) ?>
		<?= Html::label($getTotals->set_exam_avg, $getTotals->set_exam_avg, ['class' =>'col-md-1 col7']) ?>
		<?= Html::label($getTotals->set_rank, $getTotals->set_rank, ['class' =>'col-md-1 col8']) ?>
		<?php else: $action = "Add";?>
		<?= Html::textInput( 'Sub1', 0, ['onkeyup'=>'validateval(this.value)','class' =>'col-md-1 colcm','id'=>'Sub1'.$studno]) ?>
		<?= Html::textInput( 'Sub2', 0, ['onkeyup'=>'validateval(this)','class' =>'col-md-1 colcm','id'=>'Sub2'.$studno]) ?>
		<?= Html::textInput( 'Sub3', 0, ['onkeyup'=>'validateval(this)','class' =>'col-md-1 colcm','id'=>'Sub3'.$studno]) ?>
		<?= Html::label(0, 0, ['class' =>'col-md-1 col6']) ?>
		<?= Html::label(0, 0, ['class' =>'col-md-1 col7']) ?>
		<?= Html::label(0, 0, ['class' =>'col-md-1 col8']) ?>
		<?php endif; ?>
		<div class ='col-md-2 col9'>
			<?= Html::a($action, '#', ['id'=>'','onclick' =>' $.ajax({
					url: "index.php?r=site/addmarks",
					type: "POST",
					data: "studId='.$data['studId'].'&examType='.$data['examType'].'&studno='.$studno.'&sub1="+$("#Sub1'.$studno.'").val()+"&sub2="+$("#Sub2'.$studno.'").val()+"&sub3="+$("#Sub3'.$studno.'").val(),
					success  : function(data) {
							location.reload();
						}
				})
			']) ?>
			<?= Html::a('Cancel', '#', ['id'=>'','onclick' =>" $.ajax({
					url: 'index.php?r=site/upmarkscancel',
					type: 'POST',
					data: 'studId=".$data['studId']."&examType=".$data['examType']."&studno=".$studno."',
					success  : function(data) {
							$('#mark_$studno').html(data);;
						}
				})
			"]) ?>
		</div>
		<?php
	}
	public function actionAddmarks()
	{
		$data['studno']		= $_POST['studno'];
		$data['studId'] 	= $_POST['studId'];
		$data['examType'] 	= $_POST['examType']; 
		$data['sub1'] 		= $_POST['sub1']; 
		$data['sub2'] 		= $_POST['sub2']; 
		$data['sub3'] 		= $_POST['sub3'];
		$totals = SubjectTotal::find()
							->where(["set_exam_type"=>$data['examType'], "set_stud_id"=>$data['studId']])
							->one();
		if(empty($totals))
			$totals = new SubjectTotal();
		
		$totals->set_exam_total = $data['sub1']+$data['sub2']+$data['sub3'];
		$totals->set_exam_type	= $data['examType'];
		$totals->set_stud_id	= $data['studId'];
		$totals->set_exam_avg	= ($totals->set_exam_total/3);
		if($totals->save())
		{
			for($i=1;$i<4;$i++)
			{
				$entry = SubjectEntry::find()
							->where(["se_exam_type"=>$data['examType'], "se_stud_id"=>$data['studId'],"se_subj_id"=>$i])
							->one();
				if(empty($entry))
					$entry = new SubjectEntry();
				$entry->se_stud_id 		= $data['studId'];
				$entry->se_exam_type	= $data['examType'];
				$entry->se_set_id		= $totals->set_id;
				$entry->se_subj_id		= $i;
				$entry->se_subj_mark	= $data['sub'.$i];
				$entry->save();
			}
		}
		$this->updateRank($data);
	}
	function updateRank($data)
	{
		$rank = SubjectTotal::find()
							->where(["set_exam_type"=>$data['examType']])
							->orderBy("set_exam_total DESC")
							->ALL();
		$i = 1;
		foreach($rank as $val)
		{
			 $myUpdate = "UPDATE subject_entry_total SET set_rank=$i WHERE set_id =". $val['set_id'].";";
			\Yii::$app->db->createCommand($myUpdate)->execute();
			$i++;
		}
		echo "Success";
	}
	public function actionUpmarkscancel()
	{
		$data['studno']		= $_POST['studno'];
		$data['studId'] 	= $_POST['studId'];
		$data['examType'] 	=$_POST['examType'];
		$this->upmarksnew($data);
	}
	public function upmarksnew($data)
	{
		$studno = $data['studno'];
		$getTotals = SubjectTotal::find()
							->where(["set_exam_type"=>$data['examType'], "set_stud_id"=>$data['studId']])
							->with('entry')
							->one();
		$subjectId = array('1'=>'Sub1','2'=>'Sub2','3'=>'Sub3');
		if(!empty($getTotals)):
		foreach($getTotals->entry as $sub):
			
			if($sub->se_subj_id == '1')
			{
				$sub1 = Html::label( $sub->se_subj_mark, $sub->se_subj_mark, ['class' =>'col-md-1 col3']);
				unset($subjectId[1]);
			}
			elseif($sub->se_subj_id == '2')
			{
				$sub2 =  Html::label( $sub->se_subj_mark, $sub->se_subj_mark, ['class' =>'col-md-1 col4']);
				unset($subjectId[2]);
			}
			elseif($sub->se_subj_id == '3')
			{
				$sub3 = Html::label( $sub->se_subj_mark, $sub->se_subj_mark, ['class' =>'col-md-1 col5']);
				unset($subjectId[3]);
			}
		 endforeach;
		
		 foreach( $subjectId as $key=>$val):
			if($key == '1')
				$sub1 = Html::label( 0, '', ['class' =>'col-md-1 col3']);
			elseif($key == '2')
				$sub2 = Html::label( 0, '', ['class' =>'col-md-1 col4']);
			elseif($key == '3')
				$sub3 = Html::label( 0, '', ['class' =>'col-md-1 col5']);
		endforeach;
		echo $sub1.$sub2.$sub3;
		$action = "Edit";
		?>
		<?= Html::label($getTotals->set_exam_total, $getTotals->set_exam_total, ['class' =>'col-md-1 col6']) ?>
		<?= Html::label($getTotals->set_exam_avg, $getTotals->set_exam_avg, ['class' =>'col-md-1 col7']) ?>
		<?= Html::label($getTotals->set_rank, $getTotals->set_rank, ['class' =>'col-md-1 col8']) ?>
		<?php else: $action = "Add";?>
		<?= Html::label(0, 0, ['class' =>'col-md-1 col3']) ?>
		<?= Html::label(0, 0, ['class' =>'col-md-1 col4']) ?>
		<?= Html::label(0, 0, ['class' =>'col-md-1 col5']) ?>
		<?= Html::label(0, 0, ['class' =>'col-md-1 col6']) ?>
		<?= Html::label(0, 0, ['class' =>'col-md-1 col7']) ?>
		<?= Html::label(0, 0, ['class' =>'col-md-1 col8']) ?>
		 <?php endif;?>
		<div class ='col-md-1 col9'>
							<?= Html::a($action, '#', ['id'=>'','onclick' =>" $.ajax({
				url: 'index.php?r=site/upmarks',
				type: 'POST',
				data: 'studId=".$data['studId']."&examType=".$data['examType']."&studno=".$studno."',
				success  : function(data) {
						$('#Sub1.$studno').focus();
						$('#mark_$studno').html(data);;
					}
			})
		"]) ?>
		</div>
		<?php
	}
}
